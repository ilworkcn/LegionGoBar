package registry

import (
	_ "github.com/Alia5/VIIPER/device/dualsense"
	_ "github.com/Alia5/VIIPER/device/dualsenseedge"
	_ "github.com/Alia5/VIIPER/device/dualshock4"
	_ "github.com/Alia5/VIIPER/device/keyboard"
	_ "github.com/Alia5/VIIPER/device/mouse"
	_ "github.com/Alia5/VIIPER/device/ns2pro"
	_ "github.com/Alia5/VIIPER/device/steamcontroller"
	_ "github.com/Alia5/VIIPER/device/steamdeck"
	_ "github.com/Alia5/VIIPER/device/switchpro"
	_ "github.com/Alia5/VIIPER/device/xbox360"
	_ "github.com/Alia5/VIIPER/device/xboxelite2"
	_ "github.com/Alia5/VIIPER/device/xboxgip"
)
